//here the event starts
module.exports = (client, info) => {
  //console.log(String(info).grey);
}
/**
  * @INFO
  * Bot Coded by 
  * @INFO
  * Work for Milrato Development |
  * @INFO
  * Please mention him / Milrato Development, when using this Code!
  * @INFO
*/
