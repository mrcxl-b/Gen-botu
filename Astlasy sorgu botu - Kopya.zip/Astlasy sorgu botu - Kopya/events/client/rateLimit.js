//here the event starts
module.exports = (client, rateLimitData) => {
    console.log(JSON.stringify(rateLimitData).grey.italic.dim);
}
/**
  * @INFO
  * Bot Coded by 
  * @INFO
  * Work for Milrato Development
  * @INFO
  * Please mention him / Milrato Development, when using this Code!
  * @INFO
*/
